
<link href="{{ asset('/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/plugins/custom/prismjs/prismjs.bundle.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/style.bundle.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/style.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('/assets/css/themes/layout/header/base/light.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/themes/layout/header/menu/light.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/themes/layout/brand/dark.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/themes/layout/aside/dark.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/plugins/custom/datatables/datatables.bundle.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/pages/wizard/wizard-4.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/css/pages/wizard/wizard-1.css') }}" rel="stylesheet">
<link rel="shortcut icon" href="{{ asset('/assets/media/logos/aims_fav.png') }}" />
<link href="{{ asset('/assets/css/pages/login/login-3.css') }}" rel="stylesheet">
<link href="{{ asset('css/developertheme.css') }}" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />





